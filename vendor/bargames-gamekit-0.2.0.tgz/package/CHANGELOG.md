# Changelog

## 0.2.0 (2026-11-11)

From No Filter's review (the oldest game; several of its versions were better). Breaking
changes are fine: no game had adopted 0.1.0.

**Fixes**
- Admin auth: `saltFormat` ("bytes" Bingo/Pool, "string" No Filter) so existing
  password files keep working; new hashes record their format.
- Admin auth: a damaged admin file fails closed (no setup land grab, no login, no
  throw) and is left untouched; `/login` and `/setup` errors no longer escape Express 4.

**Hardening**
- Global scrypt cap (2 concurrent, queue 8, then "busy") plus a capped escalating
  delay, alongside per-IP lockout. `login()` now returns `{ ok, token } | { ok:false, reason }`.
- Length-safe constant-time compare for `ADMIN_PASSWORD`. `adminConfigured()` and
  `broken()` alongside `setupNeeded()`.

**New**
- Store: `readResult` (missing / ok / invalid), validation, absolute paths, serialized `update`.
- `createSettingStore`, `createPresetStore` (with one-time migration).
- Rooms: `codeLength` / `codeAlphabet` / `normalizeCode` (default strips to A-Z0-9);
  `create(kind, init)` runs init before `room_created`; `ctx.close()` and `safeTimeout`
  for per-room crash containment; rooms whose idle check throws are dropped;
  `notePlayers` (debounced `players_changed`); `installShutdown`; `round()` in overviews;
  `close(reason, cause)`.
- `wireBarGames`: `players_changed`; commands get `ctx.actor = "venue"`; `end` takes a reason.
- Terms: `resolveTerms`, `normalizeTerm`, `fillTerms` (server and client).
- Client: `serverOrigin` override, `SOCKET_SERVER_OPTIONS`, `CallError` with `code`
  (string or `{code,message}` ack errors), `useRoomConnection` protocol options,
  `usePublicConfig` / `loadPublicConfig` (one cached fetch).

## 0.1.0 (2026-11-10)

First cut, extracted from Bingo and Pool (their copies were identical or nearly so).

- server: `createLogger`, `createJsonStore`, `createAdminAuth`, `adminRouter`, ids, `RoomRegistry`
  (cap, idle sweep that keeps venue rooms on a TV, close causes, events, `overviews()`
  with the Bar Games Rooms-page fields).
- bargames: `wireBarGames(bg, rooms, { createVenueRoom, commands, claims })`.
- client: `createSessionStore`, `serverOrigin`, `SOCKET_OPTIONS`, `createCall`,
  `useRoomConnection`, `ErrorBoundary`, `useVenue`, `VenueBranding`, `useGameName`.
- Built against `@bargames/sdk` 0.3.0.
