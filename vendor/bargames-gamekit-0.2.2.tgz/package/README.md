# @bargames/gamekit

Shared building blocks for the Bar Games family (Bingo, Pool, CAH). Each game still owns
its rules, its `Room` class, its screens and its look. The kit owns the plumbing they had
each copied: admin login, room bookkeeping, logging, JSON storage, socket and session
handling. It also wires all of that into a Bar Games box in one call.

- **Works standalone.** Nothing here needs a box. The optional box wiring
  (`@bargames/gamekit/bargames`) goes through `@bargames/sdk`, which is inert off a box.
- **No new runtime dependencies.** `express`, `react` and `@bargames/sdk` are peer
  dependencies the games already have. `socket.io` stays the game's own: pass its
  socket in.
- Node 22, ESM, TypeScript (NodeNext), like the games.

## Install (vendored, like the SDK)

Download the tarball from this repo's latest release into the game's `vendor/` folder:

```bash
gh release download --repo thezigpc/gamekit --pattern "*.tgz" --dir vendor --clobber
```

Then point both workspaces at it, and commit the tarball. CI and `docker build` must not
need GitHub access to this repo.

```jsonc
// server/package.json and client/package.json
"@bargames/gamekit": "file:../vendor/bargames-gamekit-0.2.2.tgz"
```

Run `npm install`, then commit `vendor/` and the lockfile. **Every release has a new
version number.** A changed tarball under the same name breaks `npm ci` in the games,
because the lockfile pins its integrity hash.

## What's in it

### `@bargames/gamekit/server`

| Export | Replaces (Bingo / Pool) |
|---|---|
| `createLogger`, `log` | `server/src/util/logger.ts` (same line format, `LOG_LEVEL` read per call, null fields skipped) |
| `createJsonStore(DATA_DIR)` | `admin/store.ts`, `util/jsonFileStore.ts`: `readResult` (missing / ok / **invalid, file left untouched**), `read`, atomic `write`, per-file serialized `update`, absolute paths for `*_PATH` env overrides |
| `createSettingStore`, `createPresetStore` | one-setting stores (game name, role names, default look) and named presets with one-time migration |
| `createAdminAuth({ store, envPassword, saltFormat })` | `admin/auth.ts`: scrypt, setup once, `ADMIN_PASSWORD` env, per-IP lockout, **global verification cap + queue + capped delay**, length-safe compares, sessions with TTL, **damaged file fails closed**. Transport-free: use it over HTTP or socket.io |
| `adminRouter({ auth, clientIp })` | the HTTP status, setup, login and logout part of `admin/routes.ts` (async errors handled); mount your own routes after it |
| `newRoomCode(len, alphabet)`, `normalizeRoomCode`, `newToken`, `newId`, `newSerial`, `cryptoRand` | `rooms/ids.ts` (crypto RNG) |
| `RoomRegistry<Room>`, `safeTimeout`, `installShutdown` | `rooms/RoomManager.ts`: cap, codes, idle sweep, close causes, crash containment, debounced `players_changed`, events, `overviews()`, shutdown on signals and crashes |
| `resolveTerms`, `normalizeTerm`, `fillTerms` | renameable terms (No Filter's role names), also exported from `/client` |

Your `Room` implements the small `KitRoom` interface: `code`, `kind`, `title`,
`createdAt`, `lastActivityAt`, `close(reason, cause)`, `playerCount()`, `tableCount()`,
and optionally `phase`, `round`, `hostConnected`, `hostName`, `maxPlayers` and
`pendingClaims`, each either a plain property or a method (so an existing `phase`
state property just works), or one `overviewExtra()` returning any of them. In return, every game's admin page and the venue box's **Rooms** page
get the same view of every room.

**Password files from before the kit:** Bingo and Pool derived keys with the salt's
bytes (`saltFormat: "bytes"`, the default); No Filter used the hex string itself
(`saltFormat: "string"`). Set it to match the game's existing `admin.json`, or every
live admin is locked out. New hashes are written in that same format and record it in
the file, so rolling a deployment back to pre-kit code still reads them.

**Per-IP lockout behind Cloudflare:** standalone, a whole venue's Wi-Fi shares one
public IP, so the default lockout (10 failures / 15 min per IP) lets any guest lock the
real admin out. Games deployed that way pass `failsAllowed: Infinity` and rely on the
global cap and capped delay. On a Bar Games box `clientIp` is each device's own address,
so the default is fine there.

**Crash containment:** the registry passes `ctx` to your factory. A room calls
`ctx.close(reason)` (cause `"error"`) when its own logic fails; `safeTimeout(label, ms,
fn, (err) => ctx.close(...))` does that for timers. Only that room closes. A room whose
idle check throws is dropped, not retried forever.

```ts
const store = createJsonStore(DATA_DIR);
const auth = createAdminAuth({ store, envPassword: ADMIN_PASSWORD });
await auth.init();

const rooms = new RoomRegistry<Room>({
  create: (code, kind, ctx) => new Room(code, transport, kind, ctx),
  maxRooms: MAX_ROOMS,              // Infinity for no cap
  codeLength: 5, codeAlphabet: SERIAL_ALPHABET,   // optional; default 4 letters
  idleMinutes: () => settings.get().roomIdleMinutes,   // read fresh every sweep
  fullError: () => new GameError("ROOM_FULL"),
});

const admin = adminRouter({ auth, clientIp });
admin.get("/overview", (_req, res) => res.json({ rooms: rooms.overviews(), settings: settings.get() }));
app.use("/api/admin", admin);

installShutdown(rooms, {                                // SIGTERM, SIGINT, crashes
  flush: () => bg.flush(),
  restartReason: "Updating, back in a moment.",          // deploys
  crashReason: "Something went wrong. Please rejoin.",    // crashes (rooms close with cause "error")
  drainMs: 400,                                           // let "room closed" reach phones first
  beforeExit: () => io.close(),   // not httpServer.close(): it waits on every open WebSocket
});
// On joins, leaves and kicks (not reconnects): rooms.notePlayers(room)
// To seat the creator before room_created fires: rooms.create("patron", (room) => room.addPlayer(...))
```

### `@bargames/gamekit/bargames`

```ts
wireBarGames(bg, rooms, {
  createVenueRoom: ({ title }) => {
    const room = rooms.create("venue", (r) => (r.title = title));
    // Bingo: an empty host seat. If your host is also a player (No Filter's Judge), DON'T
    // add a seat: give the room a host key for a controller screen instead.
    const key = room.makeHostKey();
    return { room, hostUrl: `/room/${room.code}?role=table&display=1&key=${key}` };
  },
  commands: {
    start: (room) => room.startFromBox(),      // throw or return { ok:false } to refuse
    pause: (room) => room.pauseFromBox(),
    resume: (room) => room.resumeFromBox(),
    next_round: (room) => room.nextRoundFromBox(),
  },
  claims: {                                     // games with claims only (Bingo)
    confirm: (room, id) => room.resolveClaim(id, true),
    reject: (room, id, reason) => room.resolveClaim(id, false, reason),
  },
});
```

That one call:
- sets the status provider from `rooms.overviews()`;
- emits `room_created`, `room_closed` (however it closes) and debounced `players_changed`;
- calls commands with `ctx.actor === "venue"`: the box acts as the venue, never as a seat;
- handles `end` (closes the room like an admin close; the box may pass a reason);
- wraps every command so an unknown room or a throw becomes `{ ok: false, message }`;
- resolves an omitted `claimId` to the oldest pending claim.

List the matching `commands` and `events` in `bargames.json` as before.

### `@bargames/gamekit/client` (React 18)

| Export | Replaces |
|---|---|
| `createSessionStore("bingo")` | `client/src/session.ts`: per-tab seat, per-device prefs (`pref`, `json`); storage errors never throw |
| `serverOrigin({ vitePort, serverPort, override })`, `SOCKET_OPTIONS`, `createCall(socket)` | `client/src/socket.ts`; `override` = `import.meta.env.VITE_SERVER_URL`. Failed calls reject with `CallError` (`message`, `code`), whether the ack's error is a string or `{ code, message }` |
| `SOCKET_SERVER_OPTIONS` | server-side `pingInterval` 10 s / `pingTimeout` 5 s: half-open phones noticed in ~15 s. Also exported from `/server` (no React) |
| `useRoomConnection(code, { socket, call, sessions, … })` | `client/src/useRoom.ts`. Options for other protocols: `events`, `resumeArgs(session)`, `onResumed(ack)`, `parseClosed(payload)`, `serverTime(view)` |
| `ErrorBoundary` | `client/src/ErrorBoundary.tsx` (`classNames` / `fallback` keep each game's look) |
| `usePublicConfig(serverUrl, parse)`, `useGameName`, `invalidatePublicConfig()`, `useVenue`, `VenueBranding` | one cached `/api/config` fetch shared by every hook; call `invalidatePublicConfig()` after an in-app admin save so mounted hooks refetch |

```ts
// client/src/socket.ts
import { io } from "socket.io-client";
import { createCall, serverOrigin, SOCKET_OPTIONS } from "@bargames/gamekit/client";
export const serverUrl = serverOrigin({ vitePort: 5174, serverPort: 3002 });
export const socket = io(serverUrl, SOCKET_OPTIONS);
export const call = createCall(socket);
```

## Adopting it in a game

Do one area at a time, keeping the game's tests green after each:
1. logger and store;
2. admin auth and routes;
3. ids and the room registry;
4. box wiring;
5. client.

Delete each replaced file in the same commit. Standalone behaviour must stay the same:
- the same admin password file (`admin.json` in `DATA_DIR`), so existing passwords keep working;
- the same room-code alphabet and length;
- the same idle default;
- the same socket event names.

`useRoomConnection` defaults to `resume`, `state` and `closed`.

## Developing the kit

```bash
npm install
npm test            # node:test via tsx
npm run pack:vendor # build + dist-pack/bargames-gamekit-<version>.tgz
```

To release, bump `version` in `package.json`, add a `CHANGELOG.md` entry, commit, tag
`v<version>`, then attach the tarball to a GitHub release:

```bash
gh release create v0.2.2 dist-pack/bargames-gamekit-0.2.2.tgz --notes-file CHANGELOG.md
```

The kit vendors the SDK tarball it is built against (`vendor/`). Update it when the SDK
version changes.
