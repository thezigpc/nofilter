# Changelog

## 0.3.2 (2026-11-11)

From Bingo's adoption (non-breaking; still works with SDK 0.4.0, vendored with 0.5.0).
- `wireBarGames`: `claimMessages: { gone?, none? }` for the game's own words when a claim
  command is refused, and `endCause` (default `"admin"`) for rooms the box ends.
- `wireBarGames` only listens to the registry on a box (`bg.connected`).
- `notePlayers`: no `players_changed` when the count ends the window where it started (a
  join and a leave cancel out), and no timers when nothing listens.
- `useRoomConnection`: `call` is declared with method syntax, so a game's typed call
  function (narrower event names) fits without a cast.
- `SOCKET_OPTIONS` is typed `{ autoConnect: boolean; transports: string[] }`, so the
  README's `io(serverUrl, SOCKET_OPTIONS)` compiles.
- `<VenueAnnouncement />` hides itself on shared screens (SDK 0.5.0's `tableMode()` /
  `markSharedScreen()`), and its text uses `--venue-on-primary`.

## 0.3.1 (2026-11-11)

From No Filter's adoption (non-breaking).
- `<VenueAnnouncement hidden />`: hide the strip while the page is a shared/TV screen that
  only the room page can detect (a table that joined a plain room URL).

## 0.3.0 (2026-11-11)

Needs `@bargames/sdk` 0.4.0 (vendor `bargames-sdk-0.4.0.tgz` alongside it).
- Client: `<BackToGames ctx />` ("← All games" + "Also playing", landing page only) and
  `<VenueAnnouncement ctx />` (staff announcements). Both render nothing standalone.
- `useVenue` / `VenueBranding` poll the venue every 30 s (was 60 s) so announcements show
  up quickly.
- Rooms: `RoomRegistry({ joinPath: (r) => "/join/" + r.code })`, or a room's own
  `joinPath` property/method. Status carries it for venue and patron rooms, so the venue's
  games list shows a "Join" button; private rooms never get one.

## 0.2.2 (2026-11-11)

- `installShutdown` logs the stack trace of a crash, not just its message.
- Docs: use `io.close()` in `beforeExit` (httpServer.close() waits on open WebSockets).

## 0.2.1 (2026-11-11)

From No Filter's adoption (all non-breaking).
- Admin auth: new hashes are written in the configured `saltFormat` (adopting the kit stays
  reversible). README: per-IP lockout caution for standalone games behind Cloudflare.
- `KitRoom`: `phase`, `round`, `hostConnected`, `hostName`, `maxPlayers`, `pendingClaims`
  may be properties or methods; `overviewExtra()` overrides; `detail()` helper.
- `installShutdown`: `restartReason`, `crashReason` (rooms close with cause "error"),
  `drainMs` (default 400), `beforeExit`.
- `SOCKET_OPTIONS` / `SOCKET_SERVER_OPTIONS` also exported from `/server` (React-free).
- Client: `invalidatePublicConfig()` refetches every mounted public-config hook.
- `SERIAL_ALPHABET` comment corrected (31 characters).

## 0.2.0 (2026-11-11)

From No Filter's review (the oldest game; several of its versions were better). Breaking
changes are fine: no game had adopted 0.1.0.

**Fixes**
- Admin auth: `saltFormat` ("bytes" Bingo/Pool, "string" No Filter) so existing
  password files keep working; new hashes record their format.
- Admin auth: a damaged admin file fails closed (no setup land grab, no login, no
  throw) and is left untouched; `/login` and `/setup` errors no longer escape Express 4.

**Hardening**
- Global scrypt cap (2 concurrent, queue 8, then "busy") plus a capped escalating
  delay, alongside per-IP lockout. `login()` now returns `{ ok, token } | { ok:false, reason }`.
- Length-safe constant-time compare for `ADMIN_PASSWORD`. `adminConfigured()` and
  `broken()` alongside `setupNeeded()`.

**New**
- Store: `readResult` (missing / ok / invalid), validation, absolute paths, serialized `update`.
- `createSettingStore`, `createPresetStore` (with one-time migration).
- Rooms: `codeLength` / `codeAlphabet` / `normalizeCode` (default strips to A-Z0-9);
  `create(kind, init)` runs init before `room_created`; `ctx.close()` and `safeTimeout`
  for per-room crash containment; rooms whose idle check throws are dropped;
  `notePlayers` (debounced `players_changed`); `installShutdown`; `round()` in overviews;
  `close(reason, cause)`.
- `wireBarGames`: `players_changed`; commands get `ctx.actor = "venue"`; `end` takes a reason.
- Terms: `resolveTerms`, `normalizeTerm`, `fillTerms` (server and client).
- Client: `serverOrigin` override, `SOCKET_SERVER_OPTIONS`, `CallError` with `code`
  (string or `{code,message}` ack errors), `useRoomConnection` protocol options,
  `usePublicConfig` / `loadPublicConfig` (one cached fetch).

## 0.1.0 (2026-11-10)

First cut, extracted from Bingo and Pool (their copies were identical or nearly so).

- server: `createLogger`, `createJsonStore`, `createAdminAuth`, `adminRouter`, ids, `RoomRegistry`
  (cap, idle sweep that keeps venue rooms on a TV, close causes, events, `overviews()`
  with the Bar Games Rooms-page fields).
- bargames: `wireBarGames(bg, rooms, { createVenueRoom, commands, claims })`.
- client: `createSessionStore`, `serverOrigin`, `SOCKET_OPTIONS`, `createCall`,
  `useRoomConnection`, `ErrorBoundary`, `useVenue`, `VenueBranding`, `useGameName`.
- Built against `@bargames/sdk` 0.3.0.
